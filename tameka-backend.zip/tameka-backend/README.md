# Tameka Backend

The "brain" of Tameka — a FastAPI service that receives transcribed text,
routes it to Groq (fast/cheap) or Claude (stronger reasoning), stores
conversation memory in Supabase, and returns a text reply.

This service handles **text in, text out** only. Wake-word detection,
speech-to-text, and text-to-speech run on a separate local client
(e.g., a Raspberry Pi) — not covered in this repo.

## 1. Set up Supabase

1. Create a free project at https://supabase.com
2. Open the SQL Editor and run the contents of `supabase_schema.sql`
3. Grab your Project URL and `anon` key from Project Settings -> API

## 2. Get API keys

- **Groq**: free account at https://console.groq.com -> API Keys
- **Anthropic (Claude)**: https://console.anthropic.com -> API Keys

## 3. Local testing

```bash
python -m venv venv
source venv/bin/activate   # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env       # fill in your real keys
uvicorn main:app --reload
```

Test it:

```bash
curl -X POST http://localhost:8000/query \
  -H "Content-Type: application/json" \
  -d '{"text": "What time is it in Tokyo?", "user_id": "me"}'
```

## 4. Deploy to Render (free tier)

1. Push this repo to GitHub
2. On Render: New -> Web Service -> connect your repo
3. Build command: `pip install -r requirements.txt`
4. Start command: `uvicorn main:app --host 0.0.0.0 --port $PORT`
5. Add environment variables in the Render dashboard (same names as `.env.example`)
6. Deploy — note your service URL, e.g. `https://tameka-backend.onrender.com`

## 5. Keep it warm (free tier workaround)

Render's free tier sleeps after 15 minutes idle and pauses Supabase
free projects after 7 days of no activity. The included GitHub Actions
workflow (`.github/workflows/keep-alive.yml`) pings both every 10 minutes.

In your GitHub repo, add these secrets (Settings -> Secrets and variables -> Actions):

- `RENDER_URL` — your Render service URL (no trailing slash)
- `SUPABASE_URL` — your Supabase project URL
- `SUPABASE_KEY` — your Supabase anon or service key

The workflow runs automatically once merged to your default branch. You
can also trigger it manually from the Actions tab to test it right away.

## Note on Render's free tier hours

Running a free service continuously (kept warm 24/7) uses close to the
entire 750 free instance-hours/month Render allows per account. Fine if
this is your only free service — worth remembering if you add others.

## Routing logic

See `choose_model()` in `main.py`. Current rules (tune as you learn what
actually needs Claude):

- Short, simple queries (<10 words, no complex keywords) -> Groq/Llama
- Medium queries (10-25 words) -> Claude Haiku
- Long queries or ones containing words like "write", "code", "analyze",
  "explain in detail", "plan" -> Claude Sonnet

You can also force a specific model per-request by passing
`"force_model": "groq" | "claude_cheap" | "claude_strong"` in the request body.
